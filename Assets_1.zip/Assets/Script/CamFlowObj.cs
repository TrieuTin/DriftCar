using UnityEngine;

public class CamFlowObj : MonoBehaviour
{

    Transform target;   
    
    float smoothSpeed = 5f;

    GameManager gm;

    private void Start()
    {

        gm = GameObject.Find("Go").GetComponent<GameManager>();
    }

    void Update()
    {
        var listCar = gm.List_Car;

        if (listCar != null && listCar.Count > 0)
        {
            target = listCar[listCar.Count - 1].transform;
        }
    }
    public bool Position2Cars
    {
        get => gm.List_Car.Count > 1 ? gm.List_Car[gm.List_Car.Count - 2].transform.position.z <= gm.List_Car[gm.List_Car.Count - 1].transform.position.z : false;

    }
    void LateUpdate()
    {
      


        if (target == null) return;
        if (gm.List_Car.Count > 1)
        {
                     
            if (Position2Cars)
            {

                Vector3 currentPos = transform.position;

                Vector3 targetPos = new Vector3(currentPos.x, currentPos.y, target.position.z + 3);

                transform.position = Vector3.Lerp(currentPos, targetPos, smoothSpeed * Time.deltaTime);
            }
        }
        else
        {
            Vector3 currentPos = transform.position;

            Vector3 targetPos = new Vector3(currentPos.x, currentPos.y, target.position.z + 3);

            transform.position = Vector3.Lerp(currentPos, targetPos, smoothSpeed * Time.deltaTime);
        }

    }
}

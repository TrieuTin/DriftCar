using System.Collections.Generic;
using UnityEngine;

public class Configuage : MonoBehaviour
{
    public List<BoxInfo> ListBox;
    public bool isGameOver = false;
    public int indexBox = 0;
    private void Start()
    {
        isGameOver = false;
    }
}
public class BoxInfo
{
    public GameObject Box { get; set; }
    public string BoxName { set; get; }
    public bool Done { get; set; }
}

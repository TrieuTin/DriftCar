using UnityEngine;

public class pipe : MonoBehaviour
{
    float speed = 2.5f;

    void Update()
    {
        transform.position += Vector3.left * speed * Time.deltaTime;

        // Optional: destroy off-screen
        if (transform.position.x < -10f)
            Destroy(gameObject);
    }

}

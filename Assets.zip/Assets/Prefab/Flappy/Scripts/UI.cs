using UnityEngine;
using UnityEngine.SceneManagement;

public class UI : MonoBehaviour
{
    [SerializeField] Setting setting;
    public void PlayGame()
    {
        SceneManager.LoadScene(1);
    }
    public void TapToPlay()
    {

        setting.isplay = true;
        this.gameObject.SetActive(false);
    }
    public void ResetGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}

using UnityEngine;

public class Score : MonoBehaviour
{
    public Sprite[] digitSprites;  
    public Transform digitParent;  
    public GameObject digitPrefab; 

    public void ShowScore(int score)
    {
        
        foreach (Transform child in digitParent) Destroy(child.gameObject);

        string s = score.ToString();
        foreach (char c in s)
        {
            GameObject digit = Instantiate(digitPrefab, digitParent);
            int index = int.Parse(c.ToString());
           // digit.GetComponent<UnityEngine.UI.Image>().sprite = digitSprites[index];
           digit.GetComponent<UnityEngine.UI.Image>().sprite = digitSprites[c - '0'];
            digit.transform.SetParent(digitParent);

        }
    }
}

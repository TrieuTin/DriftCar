using UnityEngine;

public class Fly : MonoBehaviour
{
    [SerializeField]
    Rigidbody rb;
    float flapforce = 1300f;
    void Flap()
    {
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, 0f); // reset Y velocity for consistent flap
        rb.AddForce(Vector2.up * flapforce);
        
    }
    void Start()
    {
        
    }
    private void OnCollisionEnter(Collision collision)
    {

            Debug.Log(collision.collider.tag);
            //if(collision.collider.CompareTag("Respawn"))
            //    Debug.Log("CHET");
    }
    // Update is called once per frame
    void Update()
    {
        if(SystemTouch.Tap == TouchPhase.Began)

            Flap();
        float angle = Mathf.Clamp(rb.linearVelocity.y * 5f, -90f, 45f);
        transform.rotation = Quaternion.Euler(0, 0, angle);
    }
}

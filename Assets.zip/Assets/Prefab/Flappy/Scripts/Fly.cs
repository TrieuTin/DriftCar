using UnityEngine;

public class Fly : MonoBehaviour
{
    [SerializeField]
    Rigidbody rb;
    float flapforce = 1500f;
    [SerializeField] Setting setting;
    void Flap()
    {
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, 0f); // reset Y velocity for consistent flap
        rb.AddForce(Vector2.up * flapforce);
        
    }
    void Start()
    {
        
    }
    private void OnCollisionEnter(Collision collision)
    {


        if (collision.collider.CompareTag("Respawn")) GameObject.Find("GamePlay").GetComponent<Setting>().GameOver();

        if (collision.collider.CompareTag("Ground"))
        {
            GameObject.Find("GamePlay").GetComponent<Setting>().GameOver();
           // Time.timeScale = 0;
        }
           
    }
    // Update is called once per frame
    void Update()
    {
      
        if (setting.isplay)
        {
            rb.isKinematic = false;

            if (!setting.CanFly) return;

            if (SystemTouch.Tap == TouchPhase.Began || Input.GetKeyDown(KeyCode.Space)) Flap();

            float angle = Mathf.Clamp(rb.linearVelocity.y * 5f, -90f, 45f);

            transform.rotation = Quaternion.Euler(0, 0, angle);
        }
        else rb.isKinematic = true;
    }
}

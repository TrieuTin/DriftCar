using System.Collections.Generic;
using UnityEngine;

public class Setting : MonoBehaviour
{
    public float speedPipe=2.5f;
    public float speedGround=100f;
    public bool CanFly = true;
    public List<GameObject> ListGround;
    public bool isplay = false;
    public GameObject PanelGameOver;


    public void GameOver()
    {
        CanFly = false;
        PanelGameOver.SetActive(true);
    }
   
}

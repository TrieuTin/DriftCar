using UnityEngine;

public class SpawnPipe : MonoBehaviour
{

    [SerializeField] GameObject Prefab;
    Setting setting;
    private void Awake()
    {
        setting = GetComponent<Setting>();
    }
    void Start()
    {
        InvokeRepeating("Spawn", 1f, 2f);
    }

    void Spawn()
    {



        if (!setting.CanFly)
        {
            CancelInvoke(nameof(Spawn));
            return;
        }
        if (setting.isplay)
        {

            float Rnd_y = Random.Range(5, 9);
            Vector3 pos = new Vector3(5, Rnd_y, 0f);
            var p = Instantiate(Prefab, pos, Quaternion.identity);
            p.gameObject.GetComponent<pipe>().setting = setting;
        }

    }
    
}

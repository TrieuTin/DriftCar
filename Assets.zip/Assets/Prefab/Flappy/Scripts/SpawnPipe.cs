using UnityEngine;

public class SpawnPipe : MonoBehaviour
{

    [SerializeField] GameObject Prefab;
    void Start()
    {
        InvokeRepeating("Spawn", 1f, 2f);
    }

    void Spawn()
    {
        float Rnd_y = Random.Range(5, 9);
        Vector3 pos = new Vector3(5, Rnd_y, 0f);
        Instantiate(Prefab, pos, Quaternion.identity);
    }
    
}

using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public List<GameObject> List_Car = new List<GameObject>();
    public bool isLose = false;
    public void AddCar(GameObject car)
    {
        List_Car.Add(car);
    }
    //public void SetPlay(bool play)
    //{
    //    isPlay = true;
    //}
    
}

using UnityEngine;
using UnityEngine.EventSystems;

public class CarController : MonoBehaviour
{
    [SerializeField] WheelCollider FL, FR, BL, BR;
    [SerializeField] Rigidbody rb;
    [SerializeField] GameObject panelPlay;

    float force = 1500;
    float stability_speed = 5;
    float steering =0f;

    float normalStiffness = 1f;
    float driftStiffness = 0.25f;
    float angleSteer = 20f;
    float inputsteer = 0;
    bool _engineSwitch = true;


    bool isplay = false;

    

    private void FixedUpdate()
    {

        Drifting();

        if (_engineSwitch) Engine();
       if(!_engineSwitch) Detect();
    }
    public void PLAY()
    {
        if (!EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId))
        {


            isplay = true;
            panelPlay.SetActive(!isplay);
        }
    }
    void Drifting()
    {
        if (rb.linearVelocity.magnitude >= 3f && isplay)
        {

            if (SystemTouch.Tap == TouchPhase.Moved)
            {
                var dragtouch = SystemTouch.DragFinger;

                //Danh lai xe sang ben player touch drag
                FL.steerAngle = dragtouch * angleSteer;
                FR.steerAngle = dragtouch * angleSteer;

                //Giam ma sat cho banh sau
                WheelFrictionCurve sideways;

                sideways = BL.sidewaysFriction;

                sideways.stiffness = driftStiffness;

                BL.sidewaysFriction = sideways;

                BR.sidewaysFriction = sideways;

                //brake nhe 
                BL.brakeTorque = 1500f;
                BR.brakeTorque = 1500f;

                force = 0;
                _engineSwitch = false;
              
            }
            else if(SystemTouch.Tap == TouchPhase.Ended)
            {
                StopImmediately();

            }
          
        }       
    }
    void StopImmediately()
    {
        if (!isplay) return;
        //tat chuyen dong
        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;

        //thang gap
        FL.brakeTorque = float.MaxValue;
        FR.brakeTorque = float.MaxValue;
        BL.brakeTorque = float.MaxValue;
        BR.brakeTorque = float.MaxValue;

        // tat dong co
        
        BL.motorTorque = force;
        BR.motorTorque = force;
        
    }
    void Detect()
    {
        WheelHit hit1,hit2,hit3,hit4;

        Debug.Log("VA CHAM");

        if(FL.GetGroundHit(out hit1))
        {
            if (hit1.collider.CompareTag("Parking")) Debug.Log("hit1 ");            
        }
        if (FR.GetGroundHit(out hit2))
        {
            if (hit2.collider.CompareTag("Parking")) Debug.Log("hit2 ");
        }
        if (BL.GetGroundHit(out hit3))
        {
            if (hit3.collider.CompareTag("Parking")) Debug.Log("hit3 ");
        }
        if (BR.GetGroundHit(out hit4))
        {
            if (hit4.collider.CompareTag("Parking")) Debug.Log("hit4 ");
        }
    }
    void Engine()
    {
       // if (!isplay) return;
        //lay toc do hien tai cua xe
        float current_speed = rb.linearVelocity.magnitude;
       
        //so sanh voi toc do chuan
        if (current_speed >= stability_speed) 
        {
            //neu nhanh hon thi tat dong co ra thang
            BL.motorTorque = 0;
            BR.motorTorque = 0;
            BR.brakeTorque = 2000f;
            BL.brakeTorque = 2000f;
        }
        else
        {
            
            //cho engine hoat dong lai bo thang
            BL.motorTorque = force;
            BR.motorTorque = force;
            //nha brake chay tiep
            BR.brakeTorque = 0;
            BL.brakeTorque = 0;


        }
    }

}

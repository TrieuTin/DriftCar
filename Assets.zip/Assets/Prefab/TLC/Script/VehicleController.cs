using UnityEngine;

public class VehicleController : MonoBehaviour
{
    Vector3 pos1, pos2;
    float moveTime = 5f;
    private float t = 0f;
    [SerializeField]
    Rigidbody rb;
    private void Start()
    {
        pos1 = new Vector3(-1.2f, 0.672f, -1.9986f);
        pos2 = new Vector3(1.2f, 0.672f, -1.9986f);

       

    }
    private void FixedUpdate()
    {
       

    }
    void Update()
    {
        Move2();
    }
    float changeZ =0f;
    void Move2()
    {
        if (changeZ == 0)
            changeZ = SystemTouch.DragFinger;

        if (changeZ > 0) //0-1
        {
            ChangePosition(1.2f);
        }

        if(changeZ <0)//0-(1)
        {
            ChangePosition(-1.2f);
        }
    }
    void ChangePosition(float X)
    {        


        Vector3 currentPos = transform.position;
        Vector3 targetPos = new Vector3(X, currentPos.y, currentPos.z);
        if (Vector3.Distance(currentPos, targetPos) > .001f)
        {

            transform.position = Vector3.MoveTowards(currentPos, targetPos, 5 * Time.deltaTime);
        }
        else {
            transform.position = targetPos;
            changeZ = 0;
        }



    }
    void Move1()
    {
        if (SystemTouch.Tap == TouchPhase.Began)
        {
            t += Time.deltaTime / moveTime;

            transform.position = Vector3.Lerp(pos1, pos2, t);

            var temp = pos2;

            pos2 = pos1;

            pos1 = temp;

        }
    }
}

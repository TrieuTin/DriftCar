using UnityEngine;

public class spawnbox : MonoBehaviour
{
    [SerializeField] GameObject _prefab;
    [SerializeField] Configuage config;
    void Start()
    {
        InvokeRepeating(nameof(Spawn), 1.5f, 3.5f);
    }

    void Spawn()
    {
        if(config.isGameOver)
        {
            CancelInvoke(nameof(Spawn));
            return;

        }
        if (config.ListBox == null || config.ListBox.Count == 0) goto continues;
        else if (config.ListBox[config.ListBox.Count - 1].Done == false) {return; }

       

        continues: var pos = new Vector3(5f, 4f, 0);
        var box = Instantiate(_prefab, pos, Quaternion.identity);
        box.GetComponent<MoveBox>().speed = 3f;
        box.GetComponent<MoveBox>().config = config;
        int indexbox = config.indexBox++;
        box.name = "box" + indexbox;

        if (config.ListBox == null)
        {
            config.ListBox = new System.Collections.Generic.List<BoxInfo>();

            config.ListBox.Add(new BoxInfo
            {
                Box = box,
                Done = false,
                BoxName =box.name

            });
        }
        else
            config.ListBox.Add(new BoxInfo
            {
                Box = box,
                Done = false,
                BoxName = box.name
            }) ;
       
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}

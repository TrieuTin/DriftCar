using System.Collections.Generic;
using UnityEngine;

public class SpawnGround : MonoBehaviour
{
    [SerializeField] GameObject PrefabGround;
    [SerializeField] Transform CanvasUI;
   // List<GameObject> ListPrefab;
    [SerializeField] Setting setting;
    private void Awake()
    {
        //ListPrefab = new List<GameObject>();
        CreateGround(new Vector3(0, 0, 0));
    }

    private void Start()
    {
        InvokeRepeating(nameof(Spawn), 0.1f, 1f);
       // CreateGround(new Vector3(230, 0, 0));
    }

    void Spawn()
    {
        if (!setting.CanFly)
        {
            CancelInvoke(nameof(Spawn));
            return;
        }

        if (setting.ListGround.Count == 0)
        {
            CreateGround(new Vector3(0, 0, 0));
        }
        else
        {
            RectTransform rt = setting.ListGround[setting.ListGround.Count-1].GetComponent<RectTransform>();
            float width = rt.rect.width/2;
         
            if(setting.ListGround[setting.ListGround.Count-1].transform.position.x >=0)
            {
                CreateGround(new Vector3((width * 2) -8, 0, 0));
            }
        }
    }
    void CreateGround(Vector3 pos)
    {
        if (!setting.CanFly) return;
        var ground = Instantiate(PrefabGround, pos, Quaternion.identity);
        ground.transform.SetParent(CanvasUI, false);
        ground.gameObject.GetComponent<SlideImage>().setting = setting;
        setting.ListGround.Add(ground);
    }


}

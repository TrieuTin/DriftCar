using UnityEngine;

public class Store : MonoBehaviour
{
    public static bool HasPlayed = false;
    public bool isLose = false;
}

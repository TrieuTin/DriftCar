using UnityEngine;

public class VehicleController : MonoBehaviour
{
    Vector3 pos1, pos2;
    float moveTime = 5f;
    private float t = 0f;
    [SerializeField]
    Rigidbody rb;
    private void Start()
    {
        pos1 = transform.position;
        pos2 = new Vector3(1.2f, 0.672f, -1.9986f);

       

    }
    private void FixedUpdate()
    {
       

    }
    void Update()
    {
        Move2();
    }
    void Move2()
    {
       

        if (SystemTouch.Tap == TouchPhase.Began)
        {
            Vector3 direction = (pos2 - pos1).normalized;
            rb.MovePosition(transform.position + direction * 10 * Time.fixedDeltaTime);

            var temp = pos2;

            pos2 = pos1;

            pos1 = temp;

        }
    }
    void Move1()
    {
        if (SystemTouch.Tap == TouchPhase.Began)
        {
            t += Time.deltaTime / moveTime;

            transform.position = Vector3.Lerp(pos1, pos2, t);

            var temp = pos2;

            pos2 = pos1;

            pos1 = temp;

        }
    }
}

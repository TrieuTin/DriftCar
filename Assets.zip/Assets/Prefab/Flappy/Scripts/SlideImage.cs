using UnityEngine;

public class SlideImage : MonoBehaviour
{
   
     RectTransform rect;
    public Setting setting;

    void Start()
    {
        rect = GetComponent<RectTransform>();
    }

    
    void Update()
    {
        

        if (!setting.CanFly || !setting.isplay) return;
        rect.anchoredPosition += Vector2.left * setting.speedGround * Time.deltaTime;

        if (transform.position.x < -230f)
        {
            setting.ListGround.Remove(gameObject);
            Destroy(gameObject);
        }
    }
}

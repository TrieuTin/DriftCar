using UnityEngine;

public class Fly : MonoBehaviour
{
    [SerializeField]
    Rigidbody rb;
    float flapforce = 1500f;
    [SerializeField] Setting setting;
    [SerializeField] Score score;
    void Flap()
    {
        rb.linearVelocity = new Vector2(rb.linearVelocity.x, 0f); // reset Y velocity for consistent flap
        rb.AddForce(Vector2.up * flapforce);
        
    }
    void Start()
    {
        score.ShowScore(0);
        Time.timeScale = 1;
        rb.isKinematic = false;
    }
    private void OnCollisionEnter(Collision collision)
    {

        if (collision.collider.CompareTag("Respawn")) GameObject.Find("GamePlay").GetComponent<Setting>().GameOver();

        if (collision.collider.CompareTag("Ground"))
        {
            GameObject.Find("GamePlay").GetComponent<Setting>().GameOver();
            Time.timeScale = 0;
        }
           
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Finish"))
        {
            setting.score += 1;
            score.ShowScore(setting.score);
        }
    }
    // Update is called once per frame
    void Update()
    {
      
        if (setting.isplay)
        {
            rb.isKinematic = false;

            if (!setting.CanFly) return;

            if (SystemTouch.Tap == TouchPhase.Began) Flap();

            float angle = Mathf.Clamp(rb.linearVelocity.y * 5f, -90f, 45f);

            transform.rotation = Quaternion.Euler(0, 0, angle);
        }
        else rb.isKinematic = true;
    }
}

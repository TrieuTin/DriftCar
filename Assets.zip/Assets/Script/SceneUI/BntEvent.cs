using UnityEngine;
using UnityEngine.SceneManagement;

public class BntEvent : MonoBehaviour
{
   public void StartGame()
    {
        SceneManager.LoadScene(1);
    }
}

using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class ManagerUI : MonoBehaviour
{
    [SerializeField] GameObject panelPlay;

    [SerializeField] TMPro.TMP_Text score_text;  

    [SerializeField] GameObject panelPlayReset;
    [SerializeField] GameObject panelTable;
  
    public void PLAY()
    {
       // PlayerPrefs.SetInt("Played", true ? 1 : 0);

        if (!EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId))
        {

            Store.HasPlayed = true;

            panelPlay.SetActive(false);
            panelPlayReset.SetActive(false);
                        
        }
    }
    private void Update()
    {
        panelPlay.SetActive(!Store.HasPlayed);
    }
    public void Score(int point)
    {
        var a  = int.Parse(score_text.text) + point;
        score_text.text = a.ToString();
    }
    public void ShowButtonReset()
    {
        panelPlayReset.SetActive(true);
    }
    public void RESET()
    {
       // Show_Table(false);
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        
    }
    public void Show_Table(bool show)
    {
        panelTable.SetActive(show);
    }
}

using UnityEngine;

public class SpawnCar : MonoBehaviour
{
    [SerializeField]
    GameObject car;
    private void Start()
    {        
        var pos = new Vector3(0f, 0.522f, 0);
        CreateInstantCar(pos);
    }

    public void CreateInstantCar(Vector3 pos)
    {
        if (!gameObject.GetComponent<GameManager>().isLose)
        {
            var instant = Instantiate(car, pos, Quaternion.identity);
            GameObject.Find("Go").GetComponent<GameManager>().AddCar(instant);
        }

    }
}

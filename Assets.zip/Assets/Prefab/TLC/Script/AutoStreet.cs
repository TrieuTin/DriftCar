using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AutoStreet : MonoBehaviour
{
    [SerializeField] GameObject Prefab_Road;
    private List<GameObject> ListRoad = new List<GameObject>();
    [SerializeField] List<GameObject> Obstables;
    private float speed = 5;
    float roadLen = 0;
    float previousPosZ = 0;

    void Start()
    {
        for (int i = 0; i < 2; i++)
        {
        }
        Spawn(0);

        StartCoroutine(SpawnLoop());
    }
    IEnumerator SpawnLoop()
    {
        while (true)
        {
            DestroyRoad();

            if (ListRoad.Count < 2)
            {
                InvokeRepeating("SpawnObstacles", 1f, 3f);
                SpawnNext();
            }

            yield return new WaitForSeconds(0.5f);
        }
    }
    void SpawnObstacles()
    {
        if (Obstables != null && Obstables.Count > 0)
        {
            for (int i = 0; i < 2; i++)
            {
                var tempObj = Obstables[Random.Range(0, Obstables.Count)];

                /*put x axist*/
                var rndX = Random.Range(0, 2) == 0 ? -1.2f : 1.2f;

                //get lenght of road
                var lenRoad = ListRoad[ListRoad.Count - 1].GetComponent<Collider>().bounds.size.z;
                var lenObj = tempObj.GetComponent<Renderer>().bounds.size.z;

                float halfLen = lenRoad / 2f;

                float startZ = halfLen -1;
                float endZ = ListRoad[ListRoad.Count - 1].transform.position.z + halfLen;

                var rndZ = Random.Range(startZ, endZ);
                rndZ = previousPosZ + lenObj == rndZ ? Random.Range(previousPosZ - lenObj, previousPosZ +lenObj) : rndZ;
                previousPosZ = rndZ;
                var pos = new Vector3(rndX, tempObj.transform.position.y,rndZ);

                var obs = Instantiate(tempObj, pos, Quaternion.identity);

                obs.transform.SetParent(ListRoad[ListRoad.Count - 1].transform, true);
            }

        }
    }
    void SpawnNext()
    {
        //lay do dai cua doan duong chia 2

        roadLen= ListRoad[ListRoad.Count- 1].GetComponent<Collider>().bounds.size.z / 2;
        //lay diem origin z cua doan duong cong cho nua doan duong nhan voi 2
        var newZ = ListRoad[ListRoad.Count - 1].transform.position.z + roadLen * 2;

        Spawn(newZ);
        //SpawnObstacle(newZ);
    }
    void DestroyRoad()
    {
        if (IsOverScreen())
        {
            CancelInvoke("SpawnObstacles");

            if (ListRoad.Count > 0)
            {

                Destroy(ListRoad[0]);
                ListRoad.RemoveAt(0);
            }
        }
    }
    bool IsOverScreen()
    {
        Camera cam = Camera.main;
        Renderer rend = ListRoad[0].GetComponent<Renderer>();

        Vector3 topPoint = rend.bounds.max;

        Vector3 screenPoint = cam.WorldToScreenPoint(topPoint);
        return (screenPoint.y) < 0 || (screenPoint.y) < -100;


    }
    void Spawn(float zPos)
    {

        GameObject newRoad = Instantiate(Prefab_Road, new Vector3(0f, 0f, zPos), Quaternion.identity);

        ListRoad.Add(newRoad);

        roadLen= ListRoad[ListRoad.Count - 1].GetComponent<Collider>().bounds.size.z;


    }
    // Update is called once per frame
    void Update()
    {
        // Move roads
        if(ListRoad.Count >0)
            foreach (var road in ListRoad)
            {
                if (road != null)
                {
                    road.transform.Translate(Vector3.back * speed * Time.deltaTime);
                }
            }
    }
}

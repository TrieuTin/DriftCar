using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class RoadControl : MonoBehaviour
{
    public GameObject Road;
    float roadLength = 20f;
   // public float speed = 5f;

    public List<GameObject> Obstacles;

    int ListCount { get => instantRoad.Count > 0 ? instantRoad.Count : 0; }

    private List<GameObject> instantRoad = new List<GameObject>();

    

  
  
   
    void Start()
    {
        // Spawn 
        for (int i = 0; i < 2; i++)
        {
            Spawn(i * roadLength);
        }

        StartCoroutine(SpawnLoop());
    }

    void Update()
    {
        // Move roads
        //foreach (var road in instantRoad)
        //{
        //    if (road != null)
        //    {
        //        road.transform.Translate(Vector3.back * speed * Time.deltaTime);
        //    }
        //}

        // current_score += score_text_size * Time.deltaTime;

        // score_text.text = current_score.ToString("F2") + "Km";
        // Debug.Log(score_text.text);

       
    }
   
    void Spawn(float zPos)
    {
        
        GameObject newRoad = Instantiate(Road, new Vector3(0f, 0f, zPos), Quaternion.identity);

        instantRoad.Add(newRoad);

        

        roadLength = instantRoad[ListCount - 1].GetComponent<Collider>().bounds.size.z ;

       
    }
  
   void SpawnNext()
    {
        //lay do dai cua doan duong chia 2
        
        roadLength = instantRoad[ListCount - 1].GetComponent<Collider>().bounds.size.z / 2;
        //lay diem origin z cua doan duong cong cho nua doan duong nhan voi 2
        var newZ = instantRoad[ListCount-1 ].transform.position.z + roadLength *2;
   
        Spawn(newZ);
      
    }

  


    bool IsOverScreen()
    {
        Camera cam = Camera.main;
        Renderer rend = instantRoad[0].GetComponent<Renderer>();

        Vector3 topPoint = rend.bounds.max;

        Vector3 screenPoint = cam.WorldToScreenPoint(topPoint);      
        return (screenPoint.y) < 0 || (screenPoint.y) < -100;


    }
    bool IsOverScreen2()
    {
        Camera cam = Camera.main;
        Renderer rend = instantRoad[0].GetComponent<Renderer>();

        
        Vector3 bottomPoint = rend.bounds.min;
        Vector3 topPoint = rend.bounds.max;

        
        float height = topPoint.y - bottomPoint.y;

        
        Vector3 oneThirdPoint = bottomPoint + Vector3.up * (height / 3f);

        
        Vector3 screenPoint = cam.WorldToScreenPoint(oneThirdPoint);

        
        return screenPoint.y < 0;
    }


    void DestroyRoad()
    {
        if (IsOverScreen())
        {
            if (instantRoad.Count > 0)
            {

                Destroy(instantRoad[0]);
                instantRoad.RemoveAt(0);
            }
        }
    }

    IEnumerator SpawnLoop()
    {
        while (true)
        {
            DestroyRoad();

            if (instantRoad.Count < 2) 
            {
                SpawnNext();
            }

            yield return new WaitForSeconds(0.5f);
        }
    }
}

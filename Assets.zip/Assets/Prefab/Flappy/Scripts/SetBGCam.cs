using UnityEngine;

public class SetBGCam : MonoBehaviour
{
    [SerializeField]
    string Hex = "";
    void Start()
    {
        Camera cam = GetComponent<Camera>();
        cam.clearFlags = CameraClearFlags.SolidColor;
        cam.backgroundColor = HexToColor(Hex);
    }
    public Color HexToColor(string hex)
    {
        if (hex.Contains("#"))
        {
            hex = hex.Replace("#", "");

        }
       
        Color color;
        ColorUtility.TryParseHtmlString("#" + hex, out color);
        return color;
    }
    // Update is called once per frame
    void Update()
    {
        
    }
}

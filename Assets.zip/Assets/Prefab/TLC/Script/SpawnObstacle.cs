using System.Collections.Generic;
using UnityEngine;

public class SpawnObstacle : MonoBehaviour
{
    [SerializeField] List<GameObject> Obstables;
    void Start()
    {
        if (Obstables != null && Obstables.Count > 0) 
        {



            var rndX = Random.Range(-1.2f, 1.2f);

            var pos = new Vector3(rndX, transform.position.y*2, 10);

            var obs = Instantiate(Obstables[Random.Range(0,Obstables.Count)], pos, Quaternion.identity);

            obs.transform.SetParent(gameObject.transform,true);
        }     
    }

  
}

using System;
using System.Collections;
using UnityEngine;

public class MoveBox : MonoBehaviour
{
    Rigidbody rb;
    public  float speed = 0f;
    public Configuage config;
    bool ispendingCheck=false;
 
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.isKinematic = true;
    }

    // Update is called once per frame
    void Update()
    {


        // Optional: destroy off-screen
        if (transform.position.x < -10f)
        {
            config.ListBox.RemoveAt(config.ListBox.Count - 1);
            Destroy(gameObject);

        }

        if( config.ListBox !=null  && config.ListBox.Count >0)
            if (config.ListBox[config.ListBox.Count - 1].BoxName == this.gameObject.name)
        
                if (Input.touchCount >0)
                {
                    rb.isKinematic = false;
                    speed = 0;
                    //transform.position = Vector3.zero;
                }
                else transform.position += Vector3.left * speed * Time.deltaTime;
        

    }
    private void OnCollisionEnter(Collision collision)
    {
        
      
        if (collision.collider.CompareTag("Box") && config.ListBox[config.ListBox.Count-1].BoxName == this.gameObject.name )
        {
            Debug.Log(string.Format("Obj: {0}, tag: {1}",this.gameObject.name, collision.collider.tag));

            config.ListBox[config.ListBox.Count - 1].Done = true;

            if (config.ListBox.Count > 1)
                config.ListBox[config.ListBox.Count - 2].Box.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezePositionX;
        }

        if (collision.collider.CompareTag("Ground") && config.ListBox[config.ListBox.Count - 1].BoxName == this.gameObject.name)
        {
            Debug.Log(string.Format("Obj: {0}, tag: {1}",this.gameObject.name, collision.collider.tag));
            config.isGameOver = true;
            
        }

        foreach (var item in config.ListBox)
        {




        }

    }

    private IEnumerator WaitUntilStopped()
    {
        ispendingCheck = true;
       // Rigidbody rb = config.ListBox[config.ListBox.Count - 1].Box.GetComponent<Rigidbody>();

        // wait velocity =0
        while (rb.linearVelocity.magnitude > 0.01f)   // 0.01f min of velocity
        {
            yield return null;  // wait next frame
        }

        // it time to excute
        config.ListBox[config.ListBox.Count - 1].Done = true;

        if (config.ListBox.Count > 1)
            config.ListBox[config.ListBox.Count - 2].Box.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezePositionX;
        
        ispendingCheck = false;
    }
}

using UnityEngine;

public class SystemTouch : MonoBehaviour
{
   
   public static TouchPhase Tap
    {
        get
        {

            if (Input.touchCount > 0)
            {
                switch (Input.GetTouch(0).phase)
                {
                    case TouchPhase.Began:
                        {
                            //Begin tap
                            return TouchPhase.Began;
                        }
                    case TouchPhase.Moved:
                        {
                            //Move finger
                            return TouchPhase.Moved;
                        }
                    case TouchPhase.Stationary:
                        {
                            //Touch long time
                            return TouchPhase.Stationary;
                        }
                    case TouchPhase.Ended:
                        {
                            //End tap
                            return TouchPhase.Ended;
                        }

                    default:
                        //Cancel tap
                        return TouchPhase.Canceled;
                }
            }
            else return TouchPhase.Canceled;
        }
    }
   public static float DragFinger
    {
        get
        {
            float HorizontalAxis = 0;
            if (Input.touchCount > 0)
            {
                Touch touch = Input.GetTouch(0);

                if (touch.phase == TouchPhase.Moved)
                {
                    HorizontalAxis = Mathf.Clamp(touch.deltaPosition.x / Screen.width * 10f, -1f, 1f);
                }
            }
            return HorizontalAxis;
        }
    }
    
 
}

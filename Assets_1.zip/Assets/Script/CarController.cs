using UnityEngine;
using UnityEngine.EventSystems;

public class CarController : MonoBehaviour
{
    [SerializeField] WheelCollider FL, FR, BL, BR;
    [SerializeField] Rigidbody rb;


    float force = 1500;
    float stability_speed = 5;

    Vector3 initialForward;
    float initialAngle;
    float driftStiffness = 0.25f;
    float angleSteer = 20f;
   
    bool _engineSwitch = true;
   
 
    string w1 = "";
    string w2 = "";
    string w3 = "";
    string w4 = "";

    float VelocityCar { get => rb.linearVelocity.magnitude; }
    private void Start()
    {
        initialForward = transform.forward;
        initialAngle = CurrentAngle;
    }
    float CurrentAngle { get => Vector3.Angle(initialForward, transform.forward); }
    private void Update()
    {
       if( CurrentAngle - initialAngle >=210)
        {
            StopImmediately();
        }

        if (Lose)
        {
            
            if (Store.HasPlayed)
            {
                GameObject.Find("Go").GetComponent<GameManager>().List_Car.RemoveRange(0, GameObject.Find("Go").GetComponent<GameManager>().List_Car.Count - 1);
                GameObject.Find("Go").GetComponent<ManagerUI>().ShowButtonReset();
                GameObject.Find("Go").GetComponent<Store>().isLose = true;
                GameObject.Find("Go").GetComponent<ManagerUI>().Show_Table(true);

            }
        }

        var lstcar = GameObject.Find("Go").GetComponent<GameManager>().List_Car;
                
        if(lstcar.Count > 1)
        {
            if (Camera.main.GetComponent<CamFlowObj>().Position2Cars)
            {
                Delete_GO();
            }
        }
       
    }
   
    private void FixedUpdate()
    {
        if (Input.touchCount > 0)
        {
            var touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Ended)
            {
                if (EventSystem.current.IsPointerOverGameObject(touch.fingerId)) return;
                if (force == 0)
                {
                    Detect();
                    computeScore();
                }
                Completed();
            }
        }

        Drifting();

        if (_engineSwitch) Engine();
      //  if (!_engineSwitch) Detect();
    }

    

    void Drifting()
    {
        if (Input.touchCount > 0)
        {
            var touch = Input.GetTouch(0);

            if (EventSystem.current.IsPointerOverGameObject(touch.fingerId)) return;
            else
            {
                if (rb.linearVelocity.magnitude >= 3f && Store.HasPlayed)
                {

                    if (touch.phase == TouchPhase.Moved)
                    {
                        var dragtouch = SystemTouch.DragFinger;

                        //Danh lai xe sang ben player touch drag
                        FL.steerAngle = dragtouch * angleSteer;
                        FR.steerAngle = dragtouch * angleSteer;

                        //Giam ma sat cho banh sau
                        WheelFrictionCurve sideways;

                        sideways = BL.sidewaysFriction;

                        sideways.stiffness = driftStiffness;

                        BL.sidewaysFriction = sideways;

                        BR.sidewaysFriction = sideways;

                        //brake nhe 
                        BL.brakeTorque = 1500f;
                        BR.brakeTorque = 1500f;

                        force = 0;
                        _engineSwitch = false;

                    }
                }
            }
        }
        //if (Input.touchCount > 0)
        //{
        //    var touch = Input.GetTouch(0);

        //    if (touch.phase == TouchPhase.Ended)
        //    {
        //        if (EventSystem.current.IsPointerOverGameObject(touch.fingerId)) return;
        //        if (force == 0)
        //        {
        //            Detect();
        //            computeScore();
        //        }
        //        Completed();
        //    }
        //} 
    }
    void StopImmediately()
    {
        if (!Store.HasPlayed) return;
        //tat chuyen dong
        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        force = 0;
        //thang gap
        FL.brakeTorque = float.MaxValue;
        FR.brakeTorque = float.MaxValue;
        BL.brakeTorque = float.MaxValue;
        BR.brakeTorque = float.MaxValue;

        // tat dong co
        
        BL.motorTorque = force;
        BR.motorTorque = force;
        _engineSwitch = false;
    }

    void computeScore()
    {
       
        if (EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId)) return;

        var UIText = GameObject.Find("Go").GetComponent<ManagerUI>();

        
        if (!Lose)
        {                     
            if (w1.Contains("Parking") && w2.Contains("Parking") && w3.Contains("Parking") && w4.Contains("Parking"))UIText.Score(10);
            
            if (w1.Contains("Parking")) UIText.Score(1);
            if (w2.Contains("Parking")) UIText.Score(1);
            if (w3.Contains("Parking")) UIText.Score(1);
            if (w4.Contains("Parking")) UIText.Score(1);
        }      
    }
    bool Lose
    {
        get
        {
            if (VelocityCar <=0)
            {
                var banh1 = w1.Trim() == ("Road") || w1.Trim() == "Untagged" || string.IsNullOrEmpty(w1);
                var banh2 = w2.Trim() == ("Road") || w2.Trim() == "Untagged" || string.IsNullOrEmpty(w2);
                var banh3 = w3.Trim() == ("Road") || w3.Trim() == "Untagged" || string.IsNullOrEmpty(w3);
                var banh4 = w4.Trim() == ("Road") || w4.Trim() == "Untagged" || string.IsNullOrEmpty(w4);               

                return banh1 && banh2 && banh3 && banh4;
            }
            else return false;
        }
    }
    void Detect()
    {
        WheelHit hit1,hit2,hit3,hit4;
        w1 = w2 = w3 = w4 = "";

        if (FL.GetGroundHit(out hit1))
        {
            w1=  hit1.collider.gameObject.tag;
            //if (hit1.collider.CompareTag("Parking")) UIText.Score(1);
        }
        if (FR.GetGroundHit(out hit2))
        {
            w2=  hit2.collider.gameObject.tag;
            
            //if (hit2.collider.CompareTag("Parking")) UIText.Score(1);
        }
        if (BL.GetGroundHit(out hit3))
        {
            
            w3=  hit3.collider.gameObject.tag;
            //if (hit3.collider.CompareTag("Parking")) UIText.Score(1);
        }
        if (BR.GetGroundHit(out hit4))
        {
            
            w4=  hit4.collider.gameObject.tag;
            //if (hit4.collider.CompareTag("Parking")) UIText.Score(1);
        }

      

    }
    
    void Completed()
    {
        if(force == 0)
        {
            StopImmediately();
            var lstCar = GameObject.Find("Go").GetComponent<GameManager>().List_Car;


            if (lstCar.Count == 1 && !Lose)
            {
                var oldPos = lstCar[0].transform.position;
                var pos = new Vector3(0f, 0.522f, oldPos.z - 2);
                GameObject.Find("Go").GetComponent<SpawnCar>().CreateInstantCar(pos);
            }
        }
    }
    private void OnCollisionEnter(Collision o)
    {
        if (o.collider != null && o.collider.CompareTag("Player"))
        {
            GameObject.Find("Go").GetComponent<ManagerUI>().ShowButtonReset();
        }
    }
    void Delete_GO()
    {
        Destroy(gameObject);
        GameObject.Find("Go").GetComponent<GameManager>().List_Car.Remove(gameObject);
    }
    void Engine()
    {
       // if (!isplay) return;
        //lay toc do hien tai cua xe
        float current_speed = rb.linearVelocity.magnitude;
       
        //so sanh voi toc do chuan
        if (current_speed >= stability_speed) 
        {
            //neu nhanh hon thi tat dong co ra thang
            BL.motorTorque = 0;
            BR.motorTorque = 0;
            BR.brakeTorque = 2000f;
            BL.brakeTorque = 2000f;
        }
        else
        {
            
            //cho engine hoat dong lai bo thang
            BL.motorTorque = force;
            BR.motorTorque = force;
            //nha brake chay tiep
            BR.brakeTorque = 0;
            BL.brakeTorque = 0;


        }
    }

}

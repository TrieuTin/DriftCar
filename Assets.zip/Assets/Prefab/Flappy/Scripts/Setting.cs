using System.Collections.Generic;
using UnityEngine;

public class Setting : MonoBehaviour
{
    public float speedPipe=2.5f;
    public float speedGround=100f;
    public bool CanFly = true;
    public List<GameObject> ListGround;
    public bool isplay = false;
    public int score = 0;
    [SerializeField] GameObject Panel_GameOver;
    public void GameOver()
    {
        CanFly = false;
        Panel_GameOver.SetActive(true);

    }
}
